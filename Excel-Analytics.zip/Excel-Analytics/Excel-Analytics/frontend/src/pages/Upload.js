// import React, { useState } from "react";
// import axios from "axios";
// import BackButton from "../components/BackButton";
// import "../styles/Upload.css";

// function Upload() {
//   const [file, setFile] = useState(null);
//   const [message, setMessage] = useState("");

//   const handleFileChange = (e) => {
//     setFile(e.target.files[0]);
//     setMessage("");
//   };

//   const handleUpload = async (e) => {
//     e.preventDefault();
//     setMessage("");
//     if (!file) {
//       setMessage("Please select an Excel file.");
//       return;
//     }
//     const formData = new FormData();
//     formData.append("excel", file);

//     try {
//       await axios.post("http://localhost:5000/api/upload", formData, {
//         headers: { "Content-Type": "multipart/form-data" }
//       });
//       setMessage("File uploaded and saved to database successfully!");
//       setFile(null);
//     } catch (err) {
//       setMessage("Upload failed: " + (err.response?.data?.message || err.message));
//     }
//   };

//   return (
//     <div className="upload-con">
//      <BackButton />
//       <h2>Please upload an Excel file</h2>
//       <form onSubmit={handleUpload} style={{ margin: "2rem auto", display: "inline-block" }}>
//         <input
//           type="file"
//           accept=".xlsx,.xls"
//           onChange={handleFileChange}
//           style={{ marginBottom: "1rem" }}
//         />
//         <br />
//         <button
//           type="submit"
//           style={{
//             background: "#0077cc",
//             color: "#fff",
//             border: "none",
//             borderRadius: "5px",
//             padding: "0.6rem 1.5rem",
//             fontSize: "1rem",
//             cursor: "pointer"
//           }}
//         >
//           Upload File
//         </button>
//       </form>
//       {message && <div style={{ marginTop: "1rem", color: message.startsWith("File uploaded") ? "green" : "red" }}>{message}</div>}
//     </div>
//   );
// }

// export default Upload;


import React, { useState } from "react";
import axios from "axios";
import BackButton from "../components/BackButton";
import "bootstrap/dist/css/bootstrap.min.css"; // make sure Bootstrap is imported

function Upload() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState(null); // "success" or "danger"

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setMessage("");
    setStatus(null);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    setMessage("");
    setStatus(null);

    if (!file) {
      setMessage("Please select an Excel file.");
      setStatus("danger");
      return;
    }

    const formData = new FormData();
    formData.append("excel", file);

    try {
      await axios.post("http://localhost:5000/api/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMessage("File uploaded and saved to database successfully!");
      setStatus("success");
      setFile(null);
    } catch (err) {
      setMessage(
        "Upload failed: " + (err.response?.data?.message || err.message)
      );
      setStatus("danger");
    }
  };

  return (
    <div className="container mt-5 text-center">
      <BackButton />
      <h2 className="mb-4">Please upload an Excel file</h2>

      <form onSubmit={handleUpload} className="d-flex justify-content-center">
        <table className="table table-bordered table-striped shadow w-75">
          <thead className="table-primary">
            <tr>
              <th style={{ width: "30%" }}>Field</th>
              <th>Input</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Select File</td>
              <td>
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileChange}
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
              <td>Action</td>
              <td>
                <button type="submit" className="btn btn-primary">
                  Upload File
                </button>
              </td>
            </tr>
            {message && (
              <tr>
                <td colSpan="2">
                  <div className={`alert alert-${status} mb-0`} role="alert">
                    {message}
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </form>
    </div>
  );
}

export default Upload;
